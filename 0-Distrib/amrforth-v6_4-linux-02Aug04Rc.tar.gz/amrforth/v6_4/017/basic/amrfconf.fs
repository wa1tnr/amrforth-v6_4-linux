create frequency 24000000 ,
243 constant default-TH1
true constant smod?
691 constant rom-start
create polled-kernel
: sfr-file  s" sfr-f000.fs" ;
