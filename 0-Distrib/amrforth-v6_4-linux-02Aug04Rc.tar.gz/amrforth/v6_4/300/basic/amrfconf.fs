create frequency 24500000 ,
250 constant default-TH1
true constant smod?
611 constant rom-start
create polled-kernel
: sfr-file  s" sfr-f300.fs" ;
