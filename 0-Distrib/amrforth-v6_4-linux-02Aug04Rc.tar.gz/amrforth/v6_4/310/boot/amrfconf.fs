create frequency 24500000 ,
250 constant default-TH1
true constant smod?
635 constant rom-start
create polled-kernel
: sfr-file  s" sfr-f310.fs" ;
