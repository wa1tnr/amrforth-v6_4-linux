\ job.fs
include basic.fs
\ include example.bas
include modular.bas
\ include timing.bas
