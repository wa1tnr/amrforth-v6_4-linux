create frequency 11059200 ,
253 constant default-TH1
true constant smod?
32891 constant rom-start
create polled-kernel
: sfr-file  s" sfr-552.fs" ;
