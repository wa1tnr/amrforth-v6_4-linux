\ job.fs
include basic.fs
include example.bas
