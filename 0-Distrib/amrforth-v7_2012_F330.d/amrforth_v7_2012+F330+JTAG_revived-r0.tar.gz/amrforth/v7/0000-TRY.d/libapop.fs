\ libapop.fs
0 [if]
         libapop.fs   Library to replace the missing Apop word.
using amrforth, and AM Research F300 Stamp and Developer's Motherboard

Copyright (C) 2005 by Christopher W Hafey

January 15, 2005
by: cwh

This forth source file is copyright (C) 2003 by Christopher W Hafey
and is governed by the GNU Lesser General Public License; version 2.1
of the License.

See the included file COPYING for details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

[then]

in-meta

\ was |drop:
\ copy a stack <foo> (element, item -- a complete value) 
\   from data stack to registers, destructive
a: A-pop   ( n - ) @SP A mov  SP inc  @SP 'R2 mov  SP inc ;a

\ a: R-pop-push  ( - ) @SP A mov  SP inc  @SP 'R3 mov  SP inc  ( n - )
\                       SP dec  'R3 @SP mov  SP dec  A @SP mov ;a ( - n )

\ was |dup:
\ copy the registers to the data stack as a complete value
a: oldA-push  ( - n ) SP dec  'R2 @SP mov  SP dec  A @SP mov ;a

a: old2A-push  ( - n ) SP dec  'R5 @SP mov  SP dec  'R4 @SP mov ;a
a: A-push ( -- n ) SP dec 'R5 @SP mov 'R5 R2 mov  SP dec  'R4 @SP mov   'R4 A mov ;a

\ now: R5:R4 and R4 is the lsb.

\ The problem with A-push is that we don't really know wtf will
\ be inside the R2:A pair prior to op.  Actually, we do, and the
\ news isn't good: TOS is cached there.

\ So we really need to substitute something for R2:A in our
\ A-push word -- whereas A-pop already does what we want it
\ to do.  We would also want to rename A-push to some other
\ mnemonic to indicate the changed use.

\ Further, A-pop has the almost perverse function of making a
\ good copy of what it drops, and stores the copy in the R2:A pair!
\ So, A-pop in fact (and by itself) de-synchronizes the TOS-cache.
\ It must be followed by another instruction that simply copies
\ the new TOS (established by A-pop's manipulation of SP) .. into
\ the R2:A pair.
