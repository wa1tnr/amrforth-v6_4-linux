\ job.fs

: mine (  - ) 1 drop ;
cr
cr
.( job.fs here. ) cr
.( F017 test of ttyUSB0 development Fri 6 April 2012 )
cr


\ job
\ include basic.fs  \ Has some primitives we're using.
\ include fib.fs
  include testf017.fs
\ include lcd.fs
\ include keylcd.fs
\ include timing.fs
\ include adc017.fs

