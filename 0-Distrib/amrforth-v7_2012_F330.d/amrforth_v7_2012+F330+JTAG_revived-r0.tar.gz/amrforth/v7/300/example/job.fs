\ job.fs

: test  ( n - ) for  i .  next ;

