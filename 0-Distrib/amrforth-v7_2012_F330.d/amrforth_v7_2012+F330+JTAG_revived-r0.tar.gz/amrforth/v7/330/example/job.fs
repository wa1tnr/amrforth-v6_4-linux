\ job.fs

: mine (  - ) 55 drop ;
include ustimer-cwh.fs
include main.fs

